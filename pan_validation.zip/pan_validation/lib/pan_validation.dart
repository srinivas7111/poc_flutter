library pan_validation;

// ignore: unused_import
import 'src/pan_validation_screen.dart'; // Import your screen

// Export the main widget
export 'src/pan_validation_screen.dart';
